
# BFF Architecture - Banco XYZ
Asignatura: Desarrollo Backend III (PBY2203) — Exp2_S5  

## 1. Objetivo del Proyecto
Modernizar y desacoplar los canales de atención del Banco XYZ (Web, Móvil, ATM) consumiendo el esquema de datos heredado del repositorio `bank_legacy_data`, evitando sobrecarga de payload y unificando lógica de negocio monolítica.

## 2. Estructura del Código
Multi-módulo Maven segregado por canal:
- `bff-web/`: Exige vista enriquecida de escritorio y metadatos de sesión.
- `bff-mobile/`: Filtra payload ligero (saldo y movimientos acotados).
- `bff-atm/`: Procesamiento atómico de retiros validando terminal física (`terminalId`) y saldo disponible.

## 3. Configuración de Base de Datos (Legacy)
properties
spring.datasource.url=jdbc:mysql://localhost:3306/bank_legacy?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=tu_password
spring.jpa.hibernate.ddl-auto=validate



## 4. Guía de Ejecución Local

Levanta cada servicio en terminales independientes:

bash
# Terminal 1 — Web (8081)
cd bff-web && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8081

# Terminal 2 — Móvil (8082)
cd bff-mobile && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8082

# Terminal 3 — ATM (8083)
cd bff-atm && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8083

5. Seguridad, Autenticación y Autorización
   Canal Web (8081): Autenticación por token Bearer (JWT_VERIFIED), vista enriquecida de escritorio.

Canal Móvil (8082): Autenticación de sesión ligera, payload acotado (lastMovements).

Canal ATM (8083): Mutación transaccional por POST /api/atm/withdraw exigiendo validación de contexto físico (terminalId) y saldo atómico.
(Nota local: ejecución bajo HTTP sobre Tomcat en desarrollo; despliegue productivo asume TLS/HTTPS).
```