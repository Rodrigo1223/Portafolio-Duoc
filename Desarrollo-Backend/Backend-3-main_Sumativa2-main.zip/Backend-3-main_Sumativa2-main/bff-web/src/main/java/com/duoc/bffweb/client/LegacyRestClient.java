package com.duoc.bffweb.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.util.List;
import java.util.Map;

@Component
public class LegacyRestClient {
    @Value("${legacy.base-url:https://raw.githubusercontent.com/KariVillagran/bank_legacy_data/main}")
    private String legacyBaseUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public String fetchLegacyRawData(String endpoint) {
        String base = legacyBaseUrl.endsWith("/") ? legacyBaseUrl : legacyBaseUrl + "/";
        return restTemplate.getForObject(base + endpoint, String.class);
    }

    public List<Map<String, Object>> getLegacyAccounts() {
        try {
            String base = legacyBaseUrl.endsWith("/") ? legacyBaseUrl : legacyBaseUrl + "/";
            return restTemplate.exchange(
                    base + "accounts.json",
                    HttpMethod.GET,
                    null,
                    new ParameterizedTypeReference<List<Map<String, Object>>>() {}
            ).getBody();
        } catch (Exception e) {
            return List.of(Map.of("accountId", "CTA-LEGACY-001", "holder", "Cliente Banco XYZ", "balance", 150000, "status", "ACTIVE"));
        }
    }
}