package com.duoc.bffweb.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/web/profile").hasAnyAuthority("ROLE_CLIENT", "ROLE_WEB_CLIENT", "SCOPE_web")
                        .anyRequest().authenticated()
                )
                // Filtro simulado para aceptar el Bearer dummy y mapear rol web
                .addFilterBefore((request, response, chain) -> {
                    var httpRequest = (jakarta.servlet.http.HttpServletRequest) request;
                    String authHeader = httpRequest.getHeader("Authorization");
                    if (authHeader != null && authHeader.startsWith("Bearer ")) {
                        // Contexto simulado válido para desarrollo/evaluación sumativa
                        var auth = new org.springframework.security.authentication.UsernamePasswordAuthenticationToken(
                                "web-user", null,
                                org.springframework.security.core.authority.AuthorityUtils.createAuthorityList("ROLE_CLIENT", "ROLE_WEB_CLIENT")
                        );
                        org.springframework.security.core.context.SecurityContextHolder.getContext().setAuthentication(auth);
                    }
                    chain.doFilter(request, response);
                }, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}