package com.duoc.bffweb.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

public class WebProfileDto {
    private String userId;
    private String fullName;
    private List<Map<String, Object>> accounts;
    private List<Map<String, Object>> fullTransactionHistory;

    // Constructors, Getters, Setters
    public WebProfileDto() {}

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }

    public List<Map<String, Object>> getAccounts() { return accounts; }
    public void setAccounts(List<Map<String, Object>> accounts) { this.accounts = accounts; }

    public List<Map<String, Object>> getFullTransactionHistory() { return fullTransactionHistory; }
    public void setFullTransactionHistory(List<Map<String, Object>> fullTransactionHistory) { this.fullTransactionHistory = fullTransactionHistory; }
}