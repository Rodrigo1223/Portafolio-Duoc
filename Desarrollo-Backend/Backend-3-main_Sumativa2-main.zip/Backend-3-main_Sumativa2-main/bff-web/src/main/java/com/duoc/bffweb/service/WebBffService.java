package com.duoc.bffweb.service;

import com.duoc.bffweb.client.LegacyRestClient;
import org.springframework.stereotype.Service;
import java.util.Map;

@Service
public class WebBffService {
    private final LegacyRestClient legacyRestClient;
    public WebBffService(LegacyRestClient legacyRestClient) { this.legacyRestClient = legacyRestClient; }

    public Map<String, Object> getRichWebProfile() {
        var accounts = legacyRestClient.getLegacyAccounts();
        return Map.of(
                "channel", "WEB",
                "portalVersion", "2.5.0-desktop",
                "enhancedDashboard", true,
                "accountsSummary", accounts,
                "userMetadata", Map.of("role", "ROLE_CLIENT", "sessionType", "JWT_VERIFIED")
        );
    }
}