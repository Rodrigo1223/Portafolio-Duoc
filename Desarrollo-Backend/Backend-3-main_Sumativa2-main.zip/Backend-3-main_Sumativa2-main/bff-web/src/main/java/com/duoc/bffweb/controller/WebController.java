package com.duoc.bffweb.controller;

import com.duoc.bffweb.service.WebBffService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;

@RestController
@RequestMapping("/api/web")
public class WebController {

    private final WebBffService webBffService;

    public WebController(WebBffService webBffService) {
        this.webBffService = webBffService;
    }

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getProfile() {
        return ResponseEntity.ok(webBffService.getRichWebProfile());
    }
}