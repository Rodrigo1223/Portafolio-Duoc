Actividad Sumativa (Semana 5)Nombre del paquete de entrega: Exp2_S5_Rodrigo_OlavarriaAsignatura: Desarrollo Backend III (PBY2203) — Banco XYZ1. Contexto y Decisión de DiseñoPara modernizar los canales de atención del Banco XYZ y separar las interfaces de usuario del esquema de datos heredado proveniente del repositorio bank_legacy_data, implementamos un backend segregado por canal bajo el patrón de arquitectura por canales específicos. Una pasarela única genérica habría obligado a enviar estructuras de datos pesadas innecesarias a dispositivos móviles o mezclado la lógica de validación de cajeros automáticos con la navegación web de escritorio.Canal Web (puerto 8081): Orientado a navegadores de escritorio; entrega información consolidada, historial extendido y perfiles completos de la cuenta adaptados para pantallas amplias.Canal Móvil (puerto 8082): Ajustado para dispositivos móviles; emite un resumen ligero con los datos indispensables de la cuenta para optimizar la velocidad y el consumo en redes móviles.Canal Cajeros Automáticos / ATM (puerto 8083): Diseñado para operaciones críticas como retiros y consultas de saldo, exigiendo la identificación de la terminal física (terminalId) y la validación del estado operativo para auditoría estricta.Seguridad y Acceso: Control de acceso diferenciado por canal mediante validación de credenciales y autorización por token de seguridad.2. Persistencia y Modelo de Datos LegacyLa capa de datos se conecta de forma directa al esquema relacional importado desde el repositorio base bank_legacy_data, administrado y validado en MySQL Workbench / MySQL Server.Configuración aplicada en los archivos application.properties:Propertiesspring.datasource.url=jdbc:mysql://localhost:3306/bank_legacy?useSSL=false&serverTimezone=UTC
spring.datasource.username=root
spring.datasource.password=tu_password
spring.jpa.hibernate.ddl-auto=validate
spring.jpa.database-platform=org.hibernate.dialect.MySQLDialect
spring.jpa.show-sql=true
3. Estructura de Directorios del PaquetePlaintextExp2_S5_Rodrigo_Olavarria/
├── bff-web/           # Puerto 8081 - Perfiles y vistas completas
├── bff-mobile/        # Puerto 8082 - Datos ligeros de cuenta
├── bff-atm/           # Puerto 8083 - Transacciones de cajero y saldo
├── evidencia/         # Capturas de prueba con respuesta HTTP 200 OK
│   ├── web-200.png
│   ├── mobile-200.png
│   └── atm-200.png
└── README.md          # Documentación técnica de la entrega
4. Guía de Ejecución Local Multi-PuertoPara validar la operación simultánea de los tres servicios, abra tres terminales de comandos independientes y ejecute la limpieza y arranque en cada directorio:Bash# Terminal 1 — Canal Web
cd bff-web && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8081

# Terminal 2 — Canal Móvil
cd bff-mobile && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8082

# Terminal 3 — Canal Cajero / ATM
cd bff-atm && mvn clean spring-boot:run -Dspring-boot.run.arguments=--server.port=8083
5. Matriz de Validación de Servicios (Postman)CanalMétodoRuta del ServicioCabeceras de AutorizaciónEstructura de Entrada (JSON)Estado EsperadoWebGEThttp://localhost:8081/api/web/profileAutorización: Token de seguridad (Bearer)Ninguno200 OKMobileGEThttp://localhost:8082/api/mobile/profileAutorización: Token de seguridad (Bearer)Ninguno200 OKATMPOSThttp://localhost:8083/api/atm/transactionCredenciales + Tipo de contenido (application/json){"terminalId": "ATM-EL-BOSQUE-01", "amount": 20000}200 OK6. Comportamiento y Datos Esperados por CanalCanal Web: Procesa y retorna los datos enriquecidos provenientes del archivo de cuentas del repositorio legacy mapeados al perfil de escritorio.Canal Móvil: Filtra y entrega estrictamente los campos esenciales (número de cuenta, saldo y estado) para cumplir con el requisito de bajo consumo.Canal ATM: Procesa la transacción evaluando el identificador de la terminal física del sector y el monto solicitando la aprobación del movimiento.