package com.duoc.bffmobile.dto;

import java.math.BigDecimal;
import java.util.List;

public class MobileAccountDto {
    private final String channel = "MOBILE";
    private String accountId;
    private BigDecimal balance;
    private List<String> lastMovements;

    public MobileAccountDto() {}

    public MobileAccountDto(String accountId, BigDecimal balance, List<String> lastMovements) {
        this.accountId = accountId;
        this.balance = balance;
        this.lastMovements = lastMovements;
    }

    public String getChannel() { return channel; }
    public String getAccountId() { return accountId; }
    public void setAccountId(String accountId) { this.accountId = accountId; }

    public BigDecimal getBalance() { return balance; }
    public void setBalance(BigDecimal balance) { this.balance = balance; }

    public List<String>getLastMovements() { return lastMovements; }
    public void setLastMovements(List<String> lastMovements) { this.lastMovements = lastMovements; }
}