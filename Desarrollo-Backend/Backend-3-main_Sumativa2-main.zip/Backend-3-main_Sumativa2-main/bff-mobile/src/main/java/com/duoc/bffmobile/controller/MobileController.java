package com.duoc.bffmobile.controller;

import com.duoc.bffmobile.dto.MobileAccountDto;
import com.duoc.bffmobile.service.MobileBffService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/mobile")
public class MobileController {
    private final MobileBffService mobileBffService;

    public MobileController(MobileBffService mobileBffService) {
        this.mobileBffService = mobileBffService;
    }

    @GetMapping("/profile")
    public ResponseEntity<MobileAccountDto> profile() {
        return ResponseEntity.ok(mobileBffService.getLightSummary());
    }
}