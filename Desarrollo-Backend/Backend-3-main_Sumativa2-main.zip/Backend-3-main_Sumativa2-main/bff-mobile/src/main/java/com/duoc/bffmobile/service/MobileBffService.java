package com.duoc.bffmobile.service;

import com.duoc.bffmobile.client.LegacyRestClient;
import com.duoc.bffmobile.dto.MobileAccountDto;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Service
public class MobileBffService {
    private final LegacyRestClient legacyRestClient;

    public MobileBffService(LegacyRestClient legacyRestClient) {
        this.legacyRestClient = legacyRestClient;
    }

    public MobileAccountDto getLightSummary() {
        var raw = legacyRestClient.getLegacyAccounts();
        var primary = raw.isEmpty()
                ? Map.of("balance", (Object) 150000, "accountId", "CTA-LEGACY-001")
                : raw.get(0);

        Object balanceObj = primary.get("balance");
        BigDecimal balanceVal = balanceObj instanceof Number
                ? BigDecimal.valueOf(((Number) balanceObj).doubleValue())
                : new BigDecimal("150000");

        String accountId = String.valueOf(primary.getOrDefault("accountId", "CTA-LEGACY-001"));

        return new MobileAccountDto(
                accountId,
                balanceVal,
                List.of("POS -15000", "TRANSF +50000")
        );
    }
}