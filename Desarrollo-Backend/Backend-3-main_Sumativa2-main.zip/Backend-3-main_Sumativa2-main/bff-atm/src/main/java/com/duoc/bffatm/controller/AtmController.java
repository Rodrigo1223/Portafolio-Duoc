package com.duoc.bffatm.controller;

import com.duoc.bffatm.dto.AtmTransactionDto;
import com.duoc.bffatm.service.AtmBffService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/atm")
public class AtmController {
    private final AtmBffService atmBffService;

    public AtmController(AtmBffService atmBffService) {
        this.atmBffService = atmBffService;
    }

    @PostMapping("/withdraw")
    public ResponseEntity<AtmTransactionDto> withdraw(@RequestBody Map<String, Object> payload) {
        String terminalId = (String) payload.getOrDefault("terminalId", "ATM-EL-BOSQUE-01");
        BigDecimal amount = new BigDecimal(payload.getOrDefault("amount", 20000).toString());
        return ResponseEntity.ok(atmBffService.processWithdrawal(terminalId, amount));
    }
}