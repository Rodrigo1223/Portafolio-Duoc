package com.duoc.bffatm.dto;

import java.math.BigDecimal;

public class AtmTransactionDto {
    private final String channel = "ATM";
    private String terminalId;
    private String transactionType;
    private BigDecimal amount;
    private String status;
    private BigDecimal currentBalance;
    private String accountId;

    public AtmTransactionDto() {}

    public AtmTransactionDto(String terminalId, String transactionType, BigDecimal amount, String status, BigDecimal currentBalance, String accountId) {
        this.terminalId = terminalId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.status = status;
        this.currentBalance = currentBalance;
        this.accountId = accountId;
    }

    public String getChannel() { return channel; }
    public String getTerminalId() { return terminalId; }
    public String getTransactionType() { return transactionType; }
    public BigDecimal getAmount() { return amount; }
    public String getStatus() { return status; }
    public BigDecimal getCurrentBalance() { return currentBalance; }
    public String getAccountId() { return accountId; }
}