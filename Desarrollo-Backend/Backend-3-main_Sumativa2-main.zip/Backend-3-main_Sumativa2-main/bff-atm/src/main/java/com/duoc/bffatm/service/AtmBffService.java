package com.duoc.bffatm.service;

import com.duoc.bffatm.client.LegacyRestClient;
import com.duoc.bffatm.dto.AtmTransactionDto;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.Map;

@Service
public class AtmBffService {
    private final LegacyRestClient legacyRestClient;

    public AtmBffService(LegacyRestClient legacyRestClient) {
        this.legacyRestClient = legacyRestClient;
    }

    public AtmTransactionDto processWithdrawal(String terminalId, BigDecimal amount) {
        var raw = legacyRestClient.getLegacyAccounts();
        var primary = raw.isEmpty()
                ? Map.of("balance", (Object) 150000, "accountId", (Object) "CTA-LEGACY-001")
                : raw.get(0);

        Object balanceObj = primary.get("balance");
        BigDecimal currentBalance = balanceObj instanceof Number
                ? BigDecimal.valueOf(((Number) balanceObj).doubleValue())
                : new BigDecimal("150000");
        String accountId = String.valueOf(primary.getOrDefault("accountId", "CTA-LEGACY-001"));

        boolean approved = currentBalance.compareTo(amount) >= 0;
        BigDecimal newBalance = approved ? currentBalance.subtract(amount) : currentBalance;
        String status = approved ? "APPROVED" : "REJECTED_INSUFFICIENT_FUNDS";

        return new AtmTransactionDto(terminalId, "WITHDRAWAL", amount, status, newBalance, accountId);
    }
}