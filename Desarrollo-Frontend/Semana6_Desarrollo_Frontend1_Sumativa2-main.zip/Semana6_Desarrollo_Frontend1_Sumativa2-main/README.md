# Gabinete Local — E-commerce (Semana 6)

Mini SPA de e-commerce armando catálogo de hardware con Bootstrap 5 y JavaScript vainilla.

## Estructura
```text
├── assets/
│   ├── css/styles.css
│   ├── img/          # Imágenes de los productos
│   └── js/main.js    # Lógica de fetch, carrito y filtros
├── index.html
└── productos.json    # Catálogo base
Lo que hace el código
Carga y Resiliencia: Intenta leer productos.json con fetch. Si hay atado de red o restricción de seguridad del navegador por archivo local (file://), salta el catch, muestra una alerta visual amarilla en pantalla y carga un respaldo seguro (fallbackLocal) para no dejar la página en blanco.

Carrito: Permite agregar productos, calcula subtotales y actualiza el total en CLP de forma dinámica.

Búsqueda / Filtros: Filtra por categoría en el navbar o busca por texto en tiempo real. Si no hay coincidencias, tira un aviso limpio en el DOM.