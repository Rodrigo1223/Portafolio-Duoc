// ==========================================
// ESTADO GLOBAL DE LA APLICACIÓN
// ==========================================
let productosGlobal = [];
let carrito = [];

// ==========================================
// REFERENCIAS A ELEMENTOS DEL DOM
// ==========================================
const contenedorProductos = document.getElementById('contenedor-productos');
const listaCarrito = document.getElementById('lista-carrito');
const totalCarritoElem = document.getElementById('total-carrito');
const alertaError = document.getElementById('alerta-error');
const formBusqueda = document.getElementById('form-busqueda');
const inputBusqueda = document.getElementById('input-busqueda');

// Respaldo de seguridad local con rutas exactas a assets/img/
const fallbackLocal = [
  { id: 1, nombre: "ASUS Vivobook Pro 15 OLED", categoria: "Electronica", precio: 899000, imagen: "assets/img/notebook.jpg" },
  { id: 2, nombre: "Mouse Gamer RGB Ergonómico", categoria: "Accesorios", precio: 29990, imagen: "assets/img/mouse.jpg" },
  { id: 3, nombre: "Monitor / Pantalla de Trabajo", categoria: "Electronica", precio: 179990, imagen: "assets/img/monitor.jpg" },
  { id: 4, nombre: "Teclado Mecánico 75% Custom", categoria: "Accesorios", precio: 69990, imagen: "assets/img/teclado.jpg" }
];

// Fallback visual SVG en caso de que una imagen local falle
const fallBackImg = "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='180' fill='%231e293b'><rect width='100%' height='100%'/><text x='50%' y='50%' fill='%2394a3b8' font-family='sans-serif' font-size='13' dominant-baseline='middle' text-anchor='middle'>Foto local de hardware</text></svg>";

// ==========================================
// 1. FETCH API CON GESTIÓN DE ERRORES (IL6)
// ==========================================
async function cargarProductos() {
    try {
        const respuesta = await fetch('productos.json');
        if (!respuesta.ok) {
            throw new Error(`HTTP ${respuesta.status}`);
        }
        productosGlobal = await respuesta.json();
        ocultarAlertaError();
    } catch (error) {
        console.warn('Usando respaldo integrado local por restricción file:// o error de red:', error);
        productosGlobal = fallbackLocal;
        mostrarAlertaError('No se pudo cargar el archivo externo, usando respaldo local.');
    }
    renderizarProductos(productosGlobal);
}

function mostrarAlertaError(mensaje) {
    if (alertaError) {
        alertaError.textContent = mensaje;
        alertaError.classList.remove('d-none');
    }
}

function ocultarAlertaError() {
    if (alertaError) {
        alertaError.classList.add('d-none');
    }
}

// ==========================================
// 2. MANIPULACIÓN DEL DOM: RENDERIZADO (IL6)
// ==========================================
function renderizarProductos(lista) {
    if (!contenedorProductos) return;
    contenedorProductos.innerHTML = '';
    
    if (lista.length === 0) {
        contenedorProductos.innerHTML = '<div class="col-12"><p class="text-muted text-center py-4">No se encontraron productos disponibles.</p></div>';
        return;
    }

    lista.forEach(producto => {
        const col = document.createElement('div');
        col.className = 'col-12 col-sm-6 col-lg-3';
        col.innerHTML = `
            <div class="card h-100 shadow-sm border-0">
                <div style="height: 180px; overflow: hidden; background-color: #f1f5f9; display: flex; align-items: center; justify-content: center;">
                    <img src="${producto.imagen}" class="card-img-top w-100 h-100 object-fit-cover" alt="${producto.nombre}" onerror="this.onerror=null; this.src='${fallBackImg}';">
                </div>
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title fs-6 fw-bold mb-1">${producto.nombre}</h5>
                    <p class="card-text text-muted small mb-2">${producto.categoria}</p>
                    <p class="card-text fw-bold text-dark mt-auto mb-3">$${producto.precio.toLocaleString('es-CL')}</p>
                    <button class="btn btn-primary btn-sm btn-agregar w-100" data-id="${producto.id}">Agregar al carrito</button>
                </div>
            </div>
        `;
        contenedorProductos.appendChild(col);
    });

    asignarEventosClickBotones();
}

// ==========================================
// 3. GESTIÓN DE EVENTOS: CLICK EN CARRITO
// ==========================================
function asignarEventosClickBotones() {
    const botones = document.querySelectorAll('.btn-agregar');
    botones.forEach(btn => {
        btn.removeEventListener('click', manejarClickAgregar);
        btn.addEventListener('click', manejarClickAgregar);
    });
}

function manejarClickAgregar(e) {
    const idProducto = Number(e.currentTarget.getAttribute('data-id'));
    const productoEncontrado = productosGlobal.find(p => p.id === idProducto);
    
    if (productoEncontrado) {
        carrito.push(productoEncontrado);
        actualizarResumenCarrito();
    }
}

// ==========================================
// 4. MANIPULACIÓN DEL DOM: RESUMEN CARRITO
// ==========================================
function actualizarResumenCarrito() {
    if (!listaCarrito) return;
    listaCarrito.innerHTML = '';
    
    if (carrito.length === 0) {
        listaCarrito.innerHTML = '<li class="list-group-item text-muted small">El carrito está vacío.</li>';
        if (totalCarritoElem) totalCarritoElem.textContent = '0';
        return;
    }

    let acumuladorTotal = 0;

    carrito.forEach((item) => {
        acumuladorTotal += item.precio;
        const li = document.createElement('li');
        li.className = 'list-group-item d-flex justify-content-between align-items-center small';
        li.innerHTML = `
            <span>${item.nombre}</span>
            <span class="badge bg-secondary rounded-pill">$${item.precio.toLocaleString('es-CL')}</span>
        `;
        listaCarrito.appendChild(li);
    });

    if (totalCarritoElem) totalCarritoElem.textContent = acumuladorTotal.toLocaleString('es-CL');
}

// ==========================================
// 5. FILTRADO POR CATEGORÍA
// ==========================================
function filtrarCategoria(categoria) {
    if (!categoria || categoria.toLowerCase() === 'todos') {
        renderizarProductos(productosGlobal);
    } else {
        const filtrados = productosGlobal.filter(p => p.categoria.toLowerCase() === categoria.toLowerCase());
        renderizarProductos(filtrados);
    }
}

// Exponer globalmente para enlaces onclick del HTML
window.filtrarCategoria = filtrarCategoria;
window.filtrarPorCategoria = filtrarCategoria;

// ==========================================
// 6. GESTIÓN DE EVENTOS: SUBMIT BÚSQUEDA
// ==========================================
if (formBusqueda) {
    formBusqueda.addEventListener('submit', (e) => {
        e.preventDefault();
        const termino = inputBusqueda ? inputBusqueda.value.trim().toLowerCase() : '';
        const filtrados = productosGlobal.filter(p => 
            p.nombre.toLowerCase().includes(termino) || 
            p.categoria.toLowerCase().includes(termino)
        );
        renderizarProductos(filtrados);
    });
}

// ==========================================
// INICIALIZACIÓN AL CARGAR EL DOM
// ==========================================
document.addEventListener('DOMContentLoaded', () => {
    cargarProductos();
    actualizarResumenCarrito();
});