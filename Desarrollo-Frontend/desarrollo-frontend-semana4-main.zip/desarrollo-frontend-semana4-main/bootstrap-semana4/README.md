Actividad - Diseño Responsivo con Bootstrap 5
Este repositorio contiene la solución para la actividad de la semana, aplicando el framework Bootstrap 5 y buenas prácticas de desarrollo frontend.

🛠️ Tecnologías utilizadas
HTML5 (Estructura semántica)

Bootstrap 5 (CDN)

CSS3

📱 Características principales
Navbar Responsiva: Menú colapsable adaptable a dispositivos móviles.

Carrusel Dinámico: Configurado con un intervalo de cambio de 3 segundos.

Sistema de Grillas y Cards: Contenido organizado de manera flexible para escritorios, tablets y celulares.

🚀 Enlace al proyecto
El código fuente está estructurado en el archivo principal index.html.