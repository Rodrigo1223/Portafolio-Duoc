package cl.duoc.cdy2204.s3gestor.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import software.amazon.awssdk.core.ResponseBytes;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.DeleteObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.GetObjectResponse;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.s3.model.S3Object;

@Service
public class StorageService {

    @Autowired
    private S3Client s3Client;

    private final String BUCKET_NAME = "mibucketduocs3cvo";

    // 1. SUBIR
    public void uploadFile(String id, MultipartFile file) {
        try {
            String key = id + "/" + file.getOriginalFilename();
            PutObjectRequest putObjectRequest = PutObjectRequest.builder()
                    .bucket(BUCKET_NAME)
                    .key(key)
                    .build();
            s3Client.putObject(putObjectRequest, RequestBody.fromInputStream(file.getInputStream(), file.getSize()));
        } catch (IOException e) {
            throw new RuntimeException("Error al subir el archivo", e);
        }
    }

    // 2. LISTAR
    public List<String> listFiles(String id) {
        ListObjectsV2Request listObjects = ListObjectsV2Request.builder()
                .bucket(BUCKET_NAME)
                .prefix(id + "/")
                .build();
        return s3Client.listObjectsV2(listObjects).contents().stream()
                .map(S3Object::key)
                .collect(Collectors.toList());
    }

    // 3. DESCARGAR
    public ResponseEntity<Resource> downloadFile(String id, String fileName) {
        String key = id + "/" + fileName;
        ResponseBytes<GetObjectResponse> objectBytes = s3Client.getObjectAsBytes(GetObjectRequest.builder()
                .bucket(BUCKET_NAME)
                .key(key)
                .build());
        
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + fileName + "\"")
                .body(new InputStreamResource(new ByteArrayInputStream(objectBytes.asByteArray())));
    }

    // 4. BORRAR
    public void deleteFile(String id, String fileName) {
        String key = id + "/" + fileName;
        DeleteObjectRequest deleteObjectRequest = DeleteObjectRequest.builder()
                .bucket(BUCKET_NAME)
                .key(key)
                .build();
        s3Client.deleteObject(deleteObjectRequest);
    }
}