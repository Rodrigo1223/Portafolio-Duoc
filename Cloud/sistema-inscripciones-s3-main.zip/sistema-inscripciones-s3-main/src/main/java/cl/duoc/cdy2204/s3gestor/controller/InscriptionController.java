package cl.duoc.cdy2204.s3gestor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import cl.duoc.cdy2204.s3gestor.Service.StorageService;

@RestController
@RequestMapping("/api/inscripciones")
public class InscriptionController {

    @Autowired
    private StorageService storageService;

    // SUBIR
    @PostMapping("/{id}/upload")
    public String upload(@PathVariable String id, @RequestParam("file") MultipartFile file) {
        storageService.uploadFile(id, file);
        return "Archivo subido exitosamente en la carpeta: " + id;
    }

    // LISTAR
    @GetMapping("/{id}/list")
    public List<String> listFiles(@PathVariable String id) {
        return storageService.listFiles(id);
    }

    // DESCARGAR
    @GetMapping("/{id}/download/{fileName}")
    public ResponseEntity<Resource> downloadFile(@PathVariable String id, @PathVariable String fileName) {
        // Se agrega .trim() para limpiar espacios accidentales
        return storageService.downloadFile(id, fileName.trim());
    }

    // BORRAR
    @DeleteMapping("/{id}/delete/{fileName}")
    public String deleteFile(@PathVariable String id, @PathVariable String fileName) {
        // Se agrega .trim() para limpiar espacios accidentales
        storageService.deleteFile(id, fileName.trim());
        return "Archivo eliminado exitosamente: " + fileName.trim();
    }
}