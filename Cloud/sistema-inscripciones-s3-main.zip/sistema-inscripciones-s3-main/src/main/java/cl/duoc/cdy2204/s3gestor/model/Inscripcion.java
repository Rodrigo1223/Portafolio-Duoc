package cl.duoc.cdy2204.s3gestor.model;

public class Inscripcion {
    
}
