package cl.duoc.cdy2204.s3gestor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S3GestorInscripcionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
