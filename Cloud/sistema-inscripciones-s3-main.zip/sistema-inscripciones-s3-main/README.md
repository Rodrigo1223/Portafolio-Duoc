# Proyecto: Sistema de Gestión de Inscripciones con AWS S3

Microservicio en Spring Boot para gestionar el almacenamiento de archivos de inscripción en AWS S3. El sistema permite realizar las operaciones CRUD (subir, listar, descargar, eliminar) sobre archivos en un bucket, organizándolos en carpetas por número de inscripción.

## Especificaciones Técnicas
- **Framework:** Spring Boot 4.0.6
- **Java:** 17
- **Gestión de dependencias:** Maven
- **Dependencia clave:** `spring-cloud-aws-starter-s3` (v3.0.0)

## Funcionalidades
El sistema expone los siguientes endpoints REST:
1. **POST**: Subir un archivo de resumen a una carpeta (prefijo) en S3.
2. **GET (Listado)**: Listar archivos bajo un prefijo específico.
3. **GET (Descarga)**: Descargar archivos desde el bucket.
4. **DELETE**: Eliminar archivos específicos del bucket.

## Instrucciones de Ejecución

1. **Configurar credenciales de AWS:**
   Antes de ejecutar, configura las variables de entorno en tu terminal:

   ```bash
   # Windows (CMD)
   set AWS_ACCESS_KEY_ID=tu_access_key
   set AWS_SECRET_ACCESS_KEY=tu_secret_key
   set AWS_REGION=us-east-1

   # Linux / Mac
   export AWS_ACCESS_KEY_ID=tu_access_key
   export AWS_SECRET_ACCESS_KEY=tu_secret_key
   export AWS_REGION=us-east-1