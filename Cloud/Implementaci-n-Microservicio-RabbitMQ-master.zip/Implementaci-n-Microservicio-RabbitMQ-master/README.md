# Proyecto: Sistema de Inscripción Asíncrono - Semana 7 (CDY2204)

## Descripción del Proyecto
Este proyecto es una solución basada en microservicios desarrollada para la **Semana 7** de la asignatura **Desarrollo Cloud Native**. El sistema gestiona inscripciones de alumnos utilizando una arquitectura de mensajería asíncrona, lo que permite desacoplar la recepción de datos de su persistencia en base de datos.

## Arquitectura y Flujo de Datos
- **Productor:** Recibe la petición REST de inscripción y la encola en RabbitMQ.
- **RabbitMQ:** Actúa como intermediario de mensajería (Direct Exchange), asegurando que los mensajes no se pierdan.
- **Consumidor:** Procesa asíncronamente el mensaje y realiza la persistencia en **Oracle Database**.

## Tecnologías Utilizadas
- **Lenguaje:** Java 17+
- **Framework:** Spring Boot 3.4.1
- **Mensajería:** RabbitMQ
- **Persistencia:** Oracle Database
- **Herramientas de prueba:** Postman

## Instrucciones de Configuración
1. **Requisitos Previos:**
   - Tener instalado un servidor de RabbitMQ corriendo localmente o en un contenedor.
   - Tener una instancia de Oracle Database disponible.
   
2. **Configuración:**
   - Modifica el archivo `src/main/resources/application.properties` con tus credenciales de base de datos y la conexión a RabbitMQ.

3. **Ejecución:**
   - Desde la raíz del proyecto, ejecuta el siguiente comando en la terminal:
     ```bash
     ./mvnw spring-boot:run
     ```

## Pruebas
1. Utiliza Postman para realizar una petición `POST` al endpoint definido.
2. Verifica en los logs de la consola que el `ConsumidorService` ha procesado correctamente el mensaje.
3. Confirma en tu base de datos Oracle que el registro ha sido insertado exitosamente.

---
*Desarrollado para la asignatura Desarrollo Cloud Native (CDY2204) - Duoc UC.*