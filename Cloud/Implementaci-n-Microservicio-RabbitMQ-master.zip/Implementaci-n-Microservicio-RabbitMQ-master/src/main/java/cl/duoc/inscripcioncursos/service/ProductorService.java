package cl.duoc.inscripcioncursos.service;

import cl.duoc.inscripcioncursos.config.RabbitMQConfig;
import cl.duoc.inscripcioncursos.model.Inscripcion;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductorService {
    @Autowired
    private RabbitTemplate rabbitTemplate;

    public void enviarInscripcion(Inscripcion inscripcion) {
        rabbitTemplate.convertAndSend(RabbitMQConfig.NOMBRE_COLA, inscripcion);
    }
}