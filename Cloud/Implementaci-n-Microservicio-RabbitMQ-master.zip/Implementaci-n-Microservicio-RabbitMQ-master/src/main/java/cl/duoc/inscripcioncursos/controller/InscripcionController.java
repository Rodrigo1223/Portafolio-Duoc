package cl.duoc.inscripcioncursos.controller;

import cl.duoc.inscripcioncursos.model.Inscripcion;
import cl.duoc.inscripcioncursos.service.ProductorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity; // Importar para respuestas más limpias
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class InscripcionController {

    @Autowired
    private ProductorService productorService;

    @PostMapping("/inscripcion")
    public ResponseEntity<String> crearInscripcion(@RequestBody Inscripcion inscripcion) {
        // Validación básica antes de enviar
        if (inscripcion == null) {
            return ResponseEntity.badRequest().body("Datos de inscripción inválidos");
        }
        
        productorService.enviarInscripcion(inscripcion);
        return ResponseEntity.ok("Inscripción enviada a la cola correctamente");
    }
}