package cl.duoc.inscripcioncursos.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {
    
    public static final String NOMBRE_COLA = "cola.inscripcion";

    @Bean
    public Queue miCola() {
        return new Queue(NOMBRE_COLA, true);
    }

    // ESTE ES EL CAMBIO: 
    // Añadimos este Bean para que Spring sepa cómo convertir los mensajes 
    // a formato JSON y evitar el error de seguridad.
    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }
}