package cl.duoc.inscripcioncursos.service;

import cl.duoc.inscripcioncursos.config.RabbitMQConfig;
import cl.duoc.inscripcioncursos.model.Inscripcion;
import cl.duoc.inscripcioncursos.repository.InscripcionRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

@Service
public class ConsumidorService {

    @Autowired
    @Lazy 
    private InscripcionRepository repository;

    @RabbitListener(queues = RabbitMQConfig.NOMBRE_COLA)
    public void recibir(Inscripcion inscripcion) {
        if (repository != null) {
            repository.save(inscripcion);
            System.out.println("Inscripción procesada correctamente.");
        }
    }
}