package com.minimarket.service;

import java.util.List;

import com.minimarket.entity.DetalleVenta;

public interface DetalleVentaService {
    List<DetalleVenta> findAll();
    DetalleVenta findById(Long id);
    DetalleVenta save(DetalleVenta detalleVenta);
    void deleteById(Long id);
    List<DetalleVenta> findByVentaId(Long ventaId);
}
