package com.minimarket.service;

import java.util.List;

import com.minimarket.entity.Venta;

public interface VentaService {
    List<Venta> findAll();
    Venta findById(Long id);
    Venta save(Venta venta);
    List<Venta> findByUsuarioId(Long usuarioId);
}
